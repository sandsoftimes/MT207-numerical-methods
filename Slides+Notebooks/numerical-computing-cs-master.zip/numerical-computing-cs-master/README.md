# Numerical Computing (Full Course in Urdu) 

recluze.net 

See full video course here: https://www.youtube.com/playlist?list=PLnd7R4Mcw3rIpsOe-lijX3jtpUwPmK8n6 
